# Koschei (.ks)

> Çökmeyen, Hacklenemeyen, Ölümsüz Dil — a capability-secure programming language.

Koschei is an experimental language where **no code can touch the disk, network, environment or processes without holding a type-checked capability token**. There is no ambient authority: importing a library gives it zero power until you explicitly hand it a narrowed capability.

Born out of [Koschei Web3 Hub](https://tradepigloball.co), a live Solana security intelligence platform.

## The core idea

```ks
fn load_config(disk: DiskReadCaps, path: String) -> String or Error {
    let content = disk.read(path) or return Error("Config okunamadı: {path}")
    return content
}

fn main(caps: SystemCaps) {
    // Narrow the root capability: this directory only, read only.
    let cfg_read = caps.disk.allow_read_only("/etc/app/")
    let config = load_config(cfg_read, "/etc/app/config.json") or {
        println("Başlatma hatası")
    }
}
```

The compiler enforces, at check time:

- **KS2402** — a root capability (`caps.disk`) cannot do I/O directly; it must be narrowed first.
- **KS2403** — a narrowed capability can never be re-widened (`ro.allow("/")` does not compile).
- **KS2404** — a read-only capability cannot write.
- **KS2401** — capability-guarded operations fail in any scope that doesn't hold the token.

Plus the usual safety set: no null, immutable by default (`let` / `let mut`), errors as values (`or return` / `or default` / `or { ... }`), Bool-only conditions, and type-mismatch rejection (KS1301).

## Try it

Requires Python 3.12+. No dependencies.

```bash
python koschei.py check examples/showcase.ks
# KOSCHEI CHECK: PASS (2 fonksiyon, 8 değişken, 8 capability değeri)

python koschei.py tokens examples/capability.ks   # lexer output
python koschei.py ast examples/capability.ks      # AST as JSON
```

Run the test suite:

```bash
python -m unittest discover -s tests -v
```

## Status

v0.1 — a working lexer, recursive-descent parser and semantic/capability checker (the `check` stage). See [docs/language-core.md](docs/language-core.md) for the full language reference, error codes and known limits.

Roadmap: tree-walking interpreter → transpile to Go → enum/match, structs, generics.

Diagnostics are currently in Turkish; English localization is planned.

## License

MIT
